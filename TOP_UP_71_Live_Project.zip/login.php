<?php
require __DIR__ . '/config/bootstrap.php';
if (current_user()) redirect('account.php');
if (is_post()) {
    verify_csrf(); $email=strtolower(trim((string)($_POST['email']??''))); $pass=(string)($_POST['password']??'');
    $s=db()->prepare('SELECT id,password_hash,status FROM users WHERE email=?');$s->execute([$email]);$u=$s->fetch();
    if ($u && $u['status']==='active' && password_verify($pass,$u['password_hash'])) {login_user((int)$u['id']);redirect('account.php');}
    flash('error','Email or password is incorrect.');
}
require __DIR__.'/app/header.php'; ?>
<div class="panel" style="max-width:520px;margin:30px auto"><h1>Login</h1><form method="post"><?= csrf_field() ?><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button class="btn red">Login</button></form><p>New user? <a href="register.php">Register now</a></p></div>
<?php require __DIR__.'/app/footer.php'; ?>