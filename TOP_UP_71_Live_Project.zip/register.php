<?php
require __DIR__ . '/config/bootstrap.php';
if (current_user()) redirect('account.php');
if (is_post()) {
    verify_csrf();
    $name=trim((string)($_POST['name']??'')); $email=strtolower(trim((string)($_POST['email']??''))); $pass=(string)($_POST['password']??'');
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($pass)<10) flash('error','Enter a valid name/email and a password of at least 10 characters.');
    else {
        try {$s=db()->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)');$s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);login_user((int)db()->lastInsertId());redirect('account.php');}
        catch(PDOException $e){flash('error','This email may already be registered.');}
    }
}
require __DIR__.'/app/header.php'; ?>
<div class="panel"><h1>Create account</h1><form method="post"><?= csrf_field() ?><div class="field"><label>Name</label><input name="name" required maxlength="100"></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password (minimum 10 characters)</label><input type="password" name="password" minlength="10" required></div><button>Create account</button></form><p>Already registered? <a href="login.php">Login</a></p></div>
<?php require __DIR__.'/app/footer.php'; ?>