<?php
require __DIR__.'/config/bootstrap.php';$u=require_login();
$id=(int)($_GET['product']??0);$s=db()->prepare('SELECT * FROM products WHERE id=? AND active=1');$s->execute([$id]);$p=$s->fetch();if(!$p){flash('error','Package not found.');redirect('index.php');}
$pay=app_config()['payments'];
if(is_post()){
 verify_csrf();$uid=trim((string)($_POST['player_uid']??''));$method=(string)($_POST['payment_method']??'');$trx=trim((string)($_POST['transaction_ref']??''));
 if(!preg_match('/^[0-9]{6,20}$/',$uid) || !in_array($method,['bkash','nagad','rocket'],true) || strlen($trx)<5 || strlen($trx)>100) flash('error','Check your Player UID, payment method and transaction reference.');
 else {
  $ref=order_ref();$stmt=db()->prepare('INSERT INTO orders(order_ref,user_id,product_id,player_uid,amount,payment_method,transaction_ref,status) VALUES(?,?,?,?,?,?,?,"pending")');
  $stmt->execute([$ref,$u['id'],$p['id'],$uid,$p['price'],$method,$trx]);flash('success','Order submitted. Keep your transaction reference. Order: '.$ref);redirect('account.php');
 }
}
require __DIR__.'/app/header.php'; ?>
<div class="panel"><h1>Order: <?= e($p['name']) ?></h1><p class="price"><?= money($p['price']) ?></p><form method="post"><?= csrf_field() ?><div class="field"><label>Free Fire Player UID</label><input name="player_uid" inputmode="numeric" pattern="[0-9]{6,20}" maxlength="20" required placeholder="Enter numeric Player UID"><small class="muted">Only your public Player UID is needed. Never enter your game password or OTP.</small></div><div class="field"><label>Payment method</label><div class="method"><label><input type="radio" name="payment_method" value="bkash" required> bKash</label><label><input type="radio" name="payment_method" value="nagad"> Nagad</label><label><input type="radio" name="payment_method" value="rocket"> Rocket</label></div></div><div class="notice">Merchant payment instructions: bKash <?= e($pay['bkash_number']) ?> | Nagad <?= e($pay['nagad_number']) ?> | Rocket <?= e($pay['rocket_number']) ?>. Confirm the amount and account with the merchant before sending money.</div><div class="field"><label>Transaction ID / Reference</label><input name="transaction_ref" required maxlength="100" placeholder="Enter payment transaction reference"></div><button class="btn red">Submit order</button></form></div>
<?php require __DIR__.'/app/footer.php'; ?>