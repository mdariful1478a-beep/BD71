<?php
require __DIR__ . '/config/bootstrap.php';
$products = db()->query('SELECT id,name,diamonds,price,description FROM products WHERE active=1 ORDER BY sort_order,id')->fetchAll();
require __DIR__ . '/app/header.php';
?>
<section class="hero"><h1>Free Fire Diamond Top-Up</h1><p>Choose a package, enter your Player UID and submit your order securely.</p><a class="btn red" href="#packages">Browse packages</a></section>
<h2 id="packages">Free Fire Diamond Packages</h2>
<div class="grid"><?php foreach($products as $p): ?><article class="card"><h3><?= e($p['name']) ?></h3><p class="muted"><?= e((string)$p['diamonds']) ?> Diamonds</p><div class="price"><?= money($p['price']) ?></div><p><?= e($p['description']) ?></p><a class="btn" href="<?= e(url('order.php?product='.(int)$p['id'])) ?>">Order now</a></article><?php endforeach; ?></div>
<section class="panel rules"><h3>How it works</h3><ol><li>Select a package.</li><li>Enter your in-game Player UID. Never share your game password or OTP.</li><li>Choose a payment method and submit the transaction reference.</li><li>Admin verifies payment and processes the order.</li></ol><p class="muted">Orders are not delivered automatically unless a verified supplier API is configured.</p></section>
<?php require __DIR__ . '/app/footer.php'; ?>