<?php
require __DIR__.'/config/bootstrap.php';$u=require_login();
$s=db()->prepare('SELECT o.*,p.name product_name FROM orders o JOIN products p ON p.id=o.product_id WHERE o.user_id=? ORDER BY o.id DESC');$s->execute([$u['id']]);$orders=$s->fetchAll();
require __DIR__.'/app/header.php'; ?>
<div class="panel"><h1>My Account</h1><p>Welcome, <?= e($u['name']) ?> (<?= e($u['email']) ?>)</p><a class="btn" href="index.php">Shop diamonds</a></div>
<div class="panel"><h2>My Orders</h2><div class="table-wrap"><table><tr><th>Order</th><th>Package</th><th>Amount</th><th>Status</th><th>Date</th></tr><?php foreach($orders as $o): ?><tr><td><?= e($o['order_ref']) ?></td><td><?= e($o['product_name']) ?></td><td><?= money($o['amount']) ?></td><td><span class="badge status-<?= e($o['status']) ?>"><?= e(ucfirst($o['status'])) ?></span></td><td><?= e($o['created_at']) ?></td></tr><?php endforeach; ?></table></div><?php if(!$orders): ?><p class="muted">No orders yet.</p><?php endif; ?></div>
<?php require __DIR__.'/app/footer.php'; ?>