# TOP UP 71 — PHP/MySQL Live Hosting Starter

এটি PHP + MySQL-ভিত্তিক একটি responsive Free Fire top-up website starter project। এতে customer registration/login, package listing, UID order submission, customer order history এবং admin order-status management আছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই ZIP-এ কোনো বাস্তব bKash/Nagad/Rocket merchant API key নেই। Payment flow বর্তমানে **manual verification**: গ্রাহক transaction reference জমা দেয়, Admin merchant account-এ টাকা যাচাই করে status বদলায়।
- Automatic diamond delivery নেই। সেটির জন্য অনুমোদিত supplier-এর API documentation, credentials এবং server-side integration প্রয়োজন।
- Garena/F​​ree Fire-এর অনুমোদিত reseller/supplier হওয়া এবং সংশ্লিষ্ট brand/trademark ব্যবহারের অনুমতি নিশ্চিত করুন।
- Player UID ছাড়া game password, OTP, Facebook/Google password কখনো সংগ্রহ করবেন না।
- কোনো live payment নেওয়ার আগে gateway provider-এর merchant terms, callbacks/signature verification, refund handling এবং test environment দিয়ে integration সম্পন্ন করুন।

## Hosting requirements
- PHP 8.1+ (8.2/8.3 সুপারিশ), PDO MySQL extension
- MySQL 8+ বা MariaDB 10.5+
- HTTPS certificate
- cPanel বা VPS

## Install
1. Hosting-এ একটি MySQL database ও database user তৈরি করে privileges দিন।
2. `database/schema.sql` phpMyAdmin-এ import করুন।
3. `config/config.php`-এ DB host/name/user/password দিন। নিরাপদ হলে `config/local.php` তৈরি করে `config.php` কপি করে local secrets সেখানে রাখুন।
4. `payments` অংশে আপনার নিজস্ব merchant number বসান। কেবল আপনার নিয়ন্ত্রণাধীন এবং বৈধভাবে ব্যবহারের অনুমতি থাকা account ব্যবহার করুন।
5. সব project files `public_html`-এ upload করুন। Production-এ `config`, `app`, `database` এবং `README` web থেকে সরাসরি access করা বন্ধ করুন অথবা project-এর public document root `public/`-এ রাখুন। এই starter সহজ shared-hosting deployment-এর জন্য root entry files ব্যবহার করে; তাই `.htaccess` protection অবশ্যই রাখুন।
6. CLI access থাকলে একবার চালান: `php install_admin.php admin@example.com "Use-A-Unique-Long-Password"`
7. Admin তৈরি হলে `install_admin.php` মুছে দিন। Admin email/password নিরাপদে সংরক্ষণ করুন।
8. নিজের test account দিয়ে registration, order, payment reference এবং admin status update পরীক্ষা করুন। Production-এ যাওয়ার আগে backup ও HTTPS নিশ্চিত করুন।

## Security checklist before launch
- `config/config.php`-এর database credentials পরিবর্তন করুন; ZIP-এর কোনো default credential ব্যবহার করবেন না।
- `config`, `app`, `database`, `install_admin.php`, README এবং SQL ফাইল public HTTP access থেকে deny করুন।
- HTTPS বাধ্যতামূলক করুন; hosting-এ secure cookies ও PHP error display বন্ধ করুন।
- নিয়মিত database backup, PHP/MySQL security updates এবং admin account protection চালু রাখুন।
- Payment provider-এর official API ব্যবহার করলে server-side signature verification, idempotency, amount/currency matching, webhook replay protection এবং transaction logs যোগ করুন।
- Production payment-এর আগে আইনগত/বাণিজ্যিক অনুমতি ও provider approval নিশ্চিত করুন।

## Files
- `index.php` — storefront
- `register.php`, `login.php`, `account.php` — customer account
- `order.php` — order form
- `admin/index.php` — admin order panel
- `database/schema.sql` — database schema + starter packages
- `config/` — application configuration
