<?php
declare(strict_types=1);

/*
 * TOP UP 71 configuration.
 * Copy this file to config/local.php and keep real secrets out of public source control.
 */
return [
    'app_name' => 'TOP UP 71',
    'base_url' => '', // Example: https://example.com (no trailing slash). Leave blank for auto-detection.
    'timezone' => 'Asia/Dhaka',
    'currency' => 'BDT',
    'maintenance' => false,
    'session_name' => 'topup71_session',
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'topup71',
        'user' => 'CHANGE_DB_USER',
        'pass' => 'CHANGE_DB_PASSWORD',
        'charset' => 'utf8mb4',
    ],
    'payments' => [
        // Manual verification mode. Do not claim payment is automatic.
        'mode' => 'manual',
        'bkash_number' => 'SET_YOUR_MERCHANT_NUMBER',
        'nagad_number' => 'SET_YOUR_MERCHANT_NUMBER',
        'rocket_number' => 'SET_YOUR_MERCHANT_NUMBER',
        // Set true only after official merchant API integration has been implemented and tested.
        'gateway_enabled' => false,
    ],
    'admin' => [
        'email' => 'admin@example.com',
        // Set a strong password through the CLI installer. Never use this placeholder.
    ],
];
