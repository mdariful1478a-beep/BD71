<?php
declare(strict_types=1);

$configPath = __DIR__ . '/config.php';
$localPath = __DIR__ . '/local.php';
$config = require (is_file($localPath) ? $localPath : $configPath);
date_default_timezone_set($config['timezone'] ?? 'Asia/Dhaka');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name($config['session_name'] ?? 'topup71_session');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'secure' => $isHttps,
    'httponly' => true, 'samesite' => 'Lax'
]);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/auth.php';

function app_config(): array {
    global $config;
    return $config;
}
