CREATE DATABASE IF NOT EXISTS topup71 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE topup71;
CREATE TABLE users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
 status ENUM('active','blocked') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE products (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 diamonds INT UNSIGNED NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 description VARCHAR(255) NOT NULL DEFAULT '',
 active TINYINT(1) NOT NULL DEFAULT 1,
 sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;
CREATE TABLE orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_ref VARCHAR(40) NOT NULL UNIQUE,
 user_id BIGINT UNSIGNED NOT NULL,
 product_id INT UNSIGNED NOT NULL,
 player_uid VARCHAR(20) NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 payment_method ENUM('bkash','nagad','rocket') NOT NULL,
 transaction_ref VARCHAR(100) NOT NULL,
 status ENUM('pending','paid','completed','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL,
 CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id),
 CONSTRAINT fk_orders_product FOREIGN KEY(product_id) REFERENCES products(id),
 INDEX idx_orders_status(status), INDEX idx_orders_user(user_id)
) ENGINE=InnoDB;
CREATE TABLE settings (
 setting_key VARCHAR(100) PRIMARY KEY,
 setting_value TEXT NOT NULL
) ENGINE=InnoDB;
INSERT INTO products(name,diamonds,price,description,sort_order) VALUES
('25 Diamonds',25,22,'Free Fire diamond package',1),
('50 Diamonds',50,36,'Free Fire diamond package',2),
('115 Diamonds',115,77,'Free Fire diamond package',3),
('240 Diamonds',240,150,'Free Fire diamond package',4),
('610 Diamonds',610,380,'Free Fire diamond package',5),
('1240 Diamonds',1240,755,'Free Fire diamond package',6),
('2530 Diamonds',2530,1520,'Free Fire diamond package',7),
('5060 Diamonds',5060,3020,'Free Fire diamond package',8),
('10120 Diamonds',10120,6300,'Free Fire diamond package',9);
