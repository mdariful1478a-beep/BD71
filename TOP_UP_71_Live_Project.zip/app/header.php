<?php $user = current_user(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e(app_config()['app_name']) ?></title><link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>"></head><body>
<header class="top"><a class="brand" href="<?= e(url('index.php')) ?>"><span class="logo">RS</span><b>TOP UP 71</b></a>
<nav><?php if ($user): ?><a href="<?= e(url('account.php')) ?>">Account</a><?php if ($user['role']==='admin'): ?><a href="<?= e(url('admin/index.php')) ?>">Admin</a><?php endif; ?><a href="<?= e(url('logout.php')) ?>">Logout</a><?php else: ?><a href="<?= e(url('login.php')) ?>">Login</a><a class="btn small" href="<?= e(url('register.php')) ?>">Register</a><?php endif; ?></nav></header>
<main class="wrap">
<?php if ($m=flash('success')): ?><div class="notice success"><?= e($m) ?></div><?php endif; ?>
<?php if ($m=flash('error')): ?><div class="notice error"><?= e($m) ?></div><?php endif; ?>
