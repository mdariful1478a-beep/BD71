<?php
declare(strict_types=1);

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function redirect(string $path): never {
    $base = rtrim((string)(app_config()['base_url'] ?? ''), '/');
    header('Location: ' . $base . '/' . ltrim($path, '/')); exit;
}
function url(string $path = ''): string {
    $base = rtrim((string)(app_config()['base_url'] ?? ''), '/');
    if ($base === '') {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $https . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
        if ($script !== '/') $base .= rtrim($script, '/');
    }
    return $base . '/' . ltrim($path, '/');
}
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void {
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419); exit('Session expired. Please go back and try again.');
    }
}
function flash(string $key, ?string $message = null): ?string {
    if ($message !== null) { $_SESSION['_flash'][$key] = $message; return null; }
    $v = $_SESSION['_flash'][$key] ?? null; unset($_SESSION['_flash'][$key]); return $v;
}
function money(int|float|string $amount): string { return '৳' . number_format((float)$amount, 2); }
function setting(string $key, string $fallback = ''): string {
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        $stmt = db()->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
        $stmt->execute([$key]); $cache[$key] = $stmt->fetchColumn() ?: $fallback;
    }
    return (string)$cache[$key];
}
function order_ref(): string { return 'T71-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3))); }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
