<?php
/*
 * Run once from CLI only:
 * php install_admin.php admin@example.com "A-Long-Random-Password"
 * Delete this file after creating the administrator.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only.'); }
require __DIR__.'/config/bootstrap.php';
if ($argc !== 3 || !filter_var($argv[1],FILTER_VALIDATE_EMAIL) || strlen($argv[2])<16) {
    fwrite(STDERR,"Usage: php install_admin.php admin@example.com \"minimum-16-character-password\"\n"); exit(1);
}
$name='Site Administrator';$email=$argv[1];$hash=password_hash($argv[2],PASSWORD_DEFAULT);
$stmt=db()->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')");
$stmt->execute([$name,$email,$hash]);
echo "Admin created. Delete install_admin.php now.\n";
