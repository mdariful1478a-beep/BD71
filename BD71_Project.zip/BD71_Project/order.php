<?php
require_once __DIR__.'/includes/db.php'; require_once __DIR__.'/includes/functions.php'; require_login();
$id=(int)($_GET['package']??0); $st=$pdo->prepare('SELECT id,title,price FROM packages WHERE id=? AND is_active=1'); $st->execute([$id]); $package=$st->fetch();
if(!$package){http_response_code(404);exit('প্যাকেজ পাওয়া যায়নি। <a href="index.php">ফিরে যান</a>');}
$error=''; $done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()) $error='অনুরোধটি যাচাই করা যায়নি।';
 else { $player=trim($_POST['player_id']??''); if($player==='') $error='Player ID / প্রয়োজনীয় আইডি দিন।';
 else { $st=$pdo->prepare("INSERT INTO orders(user_id,package_id,player_id,status) VALUES(?,?,?,'pending')"); $st->execute([$_SESSION['user_id'],$package['id'],$player]); $done=true; } }
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>অর্ডার - BD71</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php">BD<span>71</span></a><nav><a href="index.php">হোম</a><a href="logout.php">লগআউট</a></nav></header><main class="form-wrap"><section class="form-card"><p class="eyebrow">PLACE ORDER</p><h1><?=e($package['title'])?></h1><p class="price">৳<?=number_format((float)$package['price'],2)?></p>
<?php if($done): ?><p class="success">আপনার ডেমো অর্ডার জমা হয়েছে। স্ট্যাটাস: Pending.</p><a class="button" href="index.php">হোমে ফিরুন</a><?php else: ?><?php if($error): ?><p class="alert"><?=e($error)?></p><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>Player ID / প্রয়োজনীয় আইডি</label><input name="player_id" required maxlength="100"><p class="note">এটি ডেমো অর্ডার। এখানে কোনো টাকা কাটা হবে না এবং কোনো বাস্তব টপ-আপ সম্পন্ন হবে না।</p><button class="button button-full">ডেমো অর্ডার জমা দিন</button></form><?php endif; ?></section></main></body></html>