CREATE DATABASE IF NOT EXISTS bd71_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bd71_db;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS packages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  description VARCHAR(255) DEFAULT '',
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  package_id INT UNSIGNED NOT NULL,
  player_id VARCHAR(100) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id),
  CONSTRAINT fk_orders_package FOREIGN KEY(package_id) REFERENCES packages(id)
) ENGINE=InnoDB;

INSERT INTO packages(title,description,price,sort_order) VALUES
('Starter Pack','ডেমো প্যাকেজ - ছোট',50,1),
('Popular Pack','ডেমো প্যাকেজ - জনপ্রিয়',100,2),
('Premium Pack','ডেমো প্যাকেজ - প্রিমিয়াম',200,3);
