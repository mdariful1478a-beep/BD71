<?php
require_once __DIR__ . '/includes/db.php';
$packages = $pdo->query("SELECT id, title, description, price FROM packages WHERE is_active = 1 ORDER BY sort_order, id")->fetchAll();
?>
<!doctype html>
<html lang="bn">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>BD71 - Top Up</title><link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topbar"><a class="brand" href="index.php">BD<span>71</span></a><nav><a href="index.php">হোম</a><a href="login.php">লগইন</a><a class="nav-btn" href="register.php">অ্যাকাউন্ট খুলুন</a></nav></header>
<main>
<section class="hero"><div><p class="eyebrow">WELCOME TO BD71</p><h1>সহজে আপনার পছন্দের<br><span>টপ-আপ প্যাকেজ</span> বেছে নিন</h1><p>প্যাকেজ নির্বাচন করে অর্ডার জমা দিন। এটি একটি ডেমো প্রজেক্ট—এখানে কোনো বাস্তব পেমেন্ট নেওয়া হয় না।</p><a class="button" href="#packages">প্যাকেজ দেখুন</a></div><div class="hero-card"><div class="orb">71</div><p>BD71 DIGITAL STORE</p><small>Fast • Simple • Secure Demo</small></div></section>
<section id="packages" class="section"><div class="section-heading"><p class="eyebrow">AVAILABLE PACKAGES</p><h2>জনপ্রিয় প্যাকেজ</h2></div>
<div class="cards">
<?php foreach ($packages as $p): ?>
<article class="package"><div class="package-icon">✦</div><h3><?= htmlspecialchars($p['title']) ?></h3><p><?= htmlspecialchars($p['description'] ?? '') ?></p><div class="price">৳<?= number_format((float)$p['price'], 2) ?></div><a class="button button-full" href="order.php?package=<?= (int)$p['id'] ?>">অর্ডার করুন</a></article>
<?php endforeach; ?>
<?php if (!$packages): ?><p>এখনো কোনো প্যাকেজ যোগ করা হয়নি। database.sql ইমপোর্ট করুন।</p><?php endif; ?>
</div></section>
</main><footer>© <?= date('Y') ?> BD71. Demo project.</footer>
</body></html>