# BD71 PHP + MySQL Starter

A starter project for a simple digital top-up storefront. It includes a home page, package list, registration, login and demo order submission.

## Requirements
- PHP 8.0 or newer
- MySQL 5.7+ / MariaDB
- Apache or another PHP-capable web server

## Run locally
1. Install XAMPP (or another PHP + MySQL environment).
2. Copy the `BD71_Project` folder into the server's web root (for XAMPP, `htdocs`).
3. Open phpMyAdmin and import `database.sql`.
4. Check database name, username and password in `includes/db.php`.
5. Open `http://localhost/BD71_Project/` in your browser.

## Deploy
Vercel static hosting does not run this PHP/MySQL application as-is. Use a PHP hosting provider with MySQL, upload the project files, import `database.sql`, and update `includes/db.php` with the host's database credentials.

## Important
- Orders are demo-only. No payment gateway or real top-up API is connected.
- Do not collect payment or publish this as a live store until you add a trusted payment provider, server-side order verification, admin controls, HTTPS, rate limiting, backups and proper privacy/security review.
- Change default database credentials for hosting. Never publish database passwords.
