<?php
// 1) Create a MySQL database and import database.sql.
// 2) Update these settings for your hosting provider.
$dbHost = 'localhost';
$dbName = 'bd71_db';
$dbUser = 'root';
$dbPass = '';
try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES => false]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check includes/db.php settings and import database.sql.');
}
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
