<?php
require_once __DIR__.'/includes/db.php'; require_once __DIR__.'/includes/functions.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()) $error='অনুরোধটি যাচাই করা যায়নি।';
 else {
  $st=$pdo->prepare('SELECT id,name,password_hash FROM users WHERE email=?'); $st->execute([trim($_POST['email']??'')]); $u=$st->fetch();
  if($u && password_verify($_POST['password']??'', $u['password_hash'])) { session_regenerate_id(true); $_SESSION['user_id']=$u['id']; $_SESSION['user_name']=$u['name']; header('Location: index.php'); exit; }
  $error='ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।';
 }
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>লগইন - BD71</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php">BD<span>71</span></a><nav><a href="index.php">হোম</a><a href="register.php">রেজিস্টার</a></nav></header>
<main class="form-wrap"><form class="form-card" method="post"><p class="eyebrow">WELCOME BACK</p><h1>লগইন</h1><?php if(isset($_GET['registered'])): ?><p class="success">অ্যাকাউন্ট তৈরি হয়েছে। এখন লগইন করুন।</p><?php endif; ?><?php if($error): ?><p class="alert"><?=e($error)?></p><?php endif; ?>
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>ইমেইল</label><input type="email" name="email" required><label>পাসওয়ার্ড</label><input type="password" name="password" required><button class="button button-full">লগইন</button><p>অ্যাকাউন্ট নেই? <a href="register.php">রেজিস্টার করুন</a></p></form></main></body></html>