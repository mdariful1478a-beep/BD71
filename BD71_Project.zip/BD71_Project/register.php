<?php
require_once __DIR__.'/includes/db.php'; require_once __DIR__.'/includes/functions.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf()) $error = 'অনুরোধটি যাচাই করা যায়নি। আবার চেষ্টা করুন।';
  else {
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $pass = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 8) $error = 'নাম, সঠিক ইমেইল এবং কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন।';
    else {
      try {
        $st = $pdo->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)');
        $st->execute([$name,$email,password_hash($pass, PASSWORD_DEFAULT)]);
        header('Location: login.php?registered=1'); exit;
      } catch (PDOException $ex) { $error = 'এই ইমেইল দিয়ে আগে অ্যাকাউন্ট খোলা হয়েছে।'; }
    }
  }
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>রেজিস্টার - BD71</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php">BD<span>71</span></a><nav><a href="index.php">হোম</a><a href="login.php">লগইন</a></nav></header>
<main class="form-wrap"><form class="form-card" method="post"><p class="eyebrow">CREATE ACCOUNT</p><h1>নতুন অ্যাকাউন্ট</h1><?php if($error): ?><p class="alert"><?=e($error)?></p><?php endif; ?>
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>আপনার নাম</label><input name="name" required maxlength="100"><label>ইমেইল</label><input type="email" name="email" required><label>পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)</label><input type="password" name="password" minlength="8" required><button class="button button-full">রেজিস্টার</button><p>আগে অ্যাকাউন্ট আছে? <a href="login.php">লগইন করুন</a></p></form></main></body></html>